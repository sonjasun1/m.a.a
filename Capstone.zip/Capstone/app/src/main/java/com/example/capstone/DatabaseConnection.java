package com.example.capstone;

import com.parse.Parse;
import com.parse.ParseACL;
import com.parse.ParseException;
import com.parse.ParseObject;
import com.parse.ParseUser;
import com.parse.SaveCallback;
import android.app.Application;
import android.util.Log;

public class DatabaseConnection extends Application {

    @Override
    public void onCreate() {
        super.onCreate();

        // This enables the local datastore.
        Parse.enableLocalDatastore(this);

        // This allows us to connect to the AWS machine that we are hosting ParseServer on.
        Parse.initialize(new Parse.Configuration.Builder(getApplicationContext())
                .applicationId("e8481fe27b0d4ee797f09669224ce7ce34f7d9dd")
                .clientKey("df390ecf03ca83f5489d5e60ea6c639a888b9a60")
                .server("http://18.218.154.203:80/parse/")
                .build()
        );

        // If anyone connects to the database/logins with the credentials given to us on the server's file ./bit_credentials
        // then they can update the database, which is what this app needs to do.
        ParseACL defaultACL = new ParseACL();
        defaultACL.setPublicReadAccess(true);
        defaultACL.setPublicWriteAccess(true);
        ParseACL.setDefaultACL(defaultACL, true);
    }
}
